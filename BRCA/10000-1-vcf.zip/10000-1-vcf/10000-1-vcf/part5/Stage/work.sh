perl /home/sunysh/12Cancer/bin/filter_stage.pl merge.unique.correct.file merge.unique.correct.filter.file
