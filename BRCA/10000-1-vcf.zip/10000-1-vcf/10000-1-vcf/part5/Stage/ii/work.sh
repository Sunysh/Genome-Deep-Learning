python /home/sunysh/12Cancer/bin/Stage/split_stage_ii.py ../../test.Matrix ../merge.unique.correct.filter.file ii /home/sunysh/12Cancer/BRCA/10000-1-vcf/part5/Stage/ii/ii.test.Matrix
